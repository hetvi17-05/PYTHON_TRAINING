from pyexpat import model
from django.db import models

# Create your models here.
class User(models.Model):
    email = models.EmailField(unique=True,max_length=30)
    password = models.CharField(max_length=30)
    role = models.CharField(max_length=30) #buyer or seller
    is_verify = models.BooleanField(default=False)
    is_active = models.BooleanField(default=False)
    create_at = models.DateTimeField(auto_now=True)

class Shopkeeper(models.Model):
    user_id = models.ForeignKey(User,on_delete=models.CASCADE)
    first_name = models.CharField(max_length=30)
    last_name = models.CharField(max_length=30,blank=True,null=True)
    shop_name = models.CharField(max_length=30)
    contact = models.CharField(max_length=10)
    address = models.TextField(max_length=200,blank=True,null=True)


class Ramspecification(models.Model):
    ram_size = models.CharField(max_length=30)

class Products(models.Model):
    user_id = models.ForeignKey(User,on_delete=models.CASCADE)
    shopkeeper_id = models.ForeignKey(Shopkeeper,on_delete=models.CASCADE)
    product_name = models.CharField(max_length=50)
    product_description = models.TextField(max_length=200)
    product_price = models.CharField(max_length=30)
    qty = models.CharField(max_length=3)
    s_id = models.ForeignKey(Ramspecification,on_delete=models.CASCADE,null=True)
    pic = models.FileField(upload_to='media/images/',default='media/product_default.png')