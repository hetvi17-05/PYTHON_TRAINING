from django.contrib import admin
from .models import *

# Register your models here.
admin.site.register(User)
admin.site.register(Shopkeeper)
admin.site.register(Products)
admin.site.register(Ramspecification)
admin.site.register(Offer)
admin.site.register(Customer)
admin.site.register(MyCart)