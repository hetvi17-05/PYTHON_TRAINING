import imp
from itertools import product
from django.shortcuts import render
from django.http import HttpResponse
from myapp.models import Products


# Create your views here.
def c_home(request):
    all_products = Products.objects.all()
    print("--------------> all ",all_products)
    context = {
        'all_products' : all_products,
    }
    return render(request,"customerApp/c_index.html",context)
