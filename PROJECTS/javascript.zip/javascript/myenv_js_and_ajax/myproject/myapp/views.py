from django.shortcuts import render
from .models import *
from django.views.decorators.csrf import csrf_exempt

# Create your views here.

def home(request):
    return render(request,"myapp/index.html")

def index(request):
    return render(request,"myapp/index.html")

@csrf_exempt
def storedata(request):
    if request.POST:
        print("----> python side ",request.POST['fname'])
        sid = Student.objects.create(firstname = request.POST['fname'],
                                    lastname = request.POST['lname'])
        return render(request,"myapp/ajax_index.html")